const { SlashCommandBuilder } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('dm')
        .setDescription('Send a direct message to a user')
        .addSubcommand(subcommand =>
            subcommand
                .setName('normal')
                .setDescription('Send a normal DM to a user')
                .addUserOption(option => 
                    option.setName('user')
                        .setDescription('The user to send the DM to')
                        .setRequired(true))
                .addStringOption(option => 
                    option.setName('message')
                        .setDescription('The message to send')
                        .setRequired(true)))
        .addSubcommand(subcommand =>
            subcommand
                .setName('anonymous')
                .setDescription('Send an anonymous DM to a user')
                .addUserOption(option => 
                    option.setName('user')
                        .setDescription('The user to send the DM to')
                        .setRequired(true))
                .addStringOption(option => 
                    option.setName('message')
                        .setDescription('The message to send')
                        .setRequired(true))),
    async execute(interaction) {
        const subcommand = interaction.options.getSubcommand();
        const user = interaction.options.getUser('user');
        const message = interaction.options.getString('message');

        try {
            if (subcommand === 'normal') {
                await user.send(`${message} \n -# Sent by ${interaction.user.username}`);
                await interaction.reply({ content: `Normal DM sent to ${user.username}.`, ephemeral: true });
            } else if (subcommand === 'anonymous') {
                await user.send(`Anonymous message: ${message}`);
                await interaction.reply({ content: `Anonymous DM sent to ${user.username}.`, ephemeral: true });
            }
        } catch (error) {
            console.error(`Error sending DM to ${user.username}:`, error);
            await interaction.reply({ content: 'There was an error while sending the message!', ephemeral: true });
        }
    }
};
