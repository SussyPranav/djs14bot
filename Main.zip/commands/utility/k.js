const { SlashCommandBuilder } = require('discord.js');
const welcomeHandler = require('../../events/guildMemberAdd.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('simulatejoin')
        .setDescription('Simulates a user joining the server.')
        .addUserOption(option => 
            option.setName('user')
                .setDescription('The user to simulate joining')
                .setRequired(true)),
    async execute(interaction) {
        const user = interaction.options.getUser('user');
        const member = await interaction.guild.members.fetch(user.id);

        try {
            await welcomeHandler(member);
            await interaction.reply({ content: `Simulated join for ${user.username}`, ephemeral: true });
        } catch (error) {
            console.error(`Error simulating join for ${user.username}:`, error);
            await interaction.reply({ content: 'There was an error while simulating the join!', ephemeral: true });
        }
    }
};
