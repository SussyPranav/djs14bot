const { SlashCommandBuilder } = require('discord.js');

module.exports = {
	data: new SlashCommandBuilder()
		.setName('secret')
		.setDescription('Send a secret message to someone!')
		.addSubcommand(subcommand =>
			subcommand
				.setName("text")
				.setDescription('Send a secret message to someone!')
                .addUserOption(option =>
					option
						.setName('target')
						.setDescription('The member you want to send the message to')
						.setRequired(true))
				.addStringOption(option =>
					option
						.setName('message')
						.setDescription('Your message')
						.setRequired(true))

		),

	async execute(interaction) {
		const { ButtonBuilder, ButtonStyle, ActionRowBuilder, EmbedBuilder, ComponentType } = require('discord.js');

		const viewButton = new ButtonBuilder()
			.setCustomId('view')
			.setLabel('View Your Message!')
			.setStyle(ButtonStyle.Secondary);

		const row = new ActionRowBuilder()
			.addComponents(viewButton);

		const target = interaction.options.getUser('target');
		const message = interaction.options.getString('message');

        if (target.bot) {
            await interaction.reply({ content: `**Um Well... I know you are alone but don't send messages to bot! 💀**`, ephemeral: true });
            return;
        } else if (interaction.user.id == target.id) {
            await interaction.reply({ content: "Uh-oh! You, my friend, are a lonely planet sending secret messages to...yourself.", ephemeral: true })
            return;
        }

        

		const viewEmbed = new EmbedBuilder()
			.setDescription(`${target.username}, you have received a secret message! \n\n-# ||Message expires in 3 minutes||`)
			.setColor("#2f3136")
			.setTimestamp();
        await interaction.reply({content: `Sent "${message}" to ${target.globalName}`, ephemeral: true}) ;
		const response =  await interaction.channel.send({
			embeds: [viewEmbed],
			components: [row],
		}); 
        

		const collector = response.createMessageComponentCollector({ componentType: ComponentType.Button, time: 180_000 });

		collector.on('collect', async i => {
			try {
				if (i.user.id !== target.id) {
					await i.reply({ content: `${i.user}, This button is not for you!`, ephemeral: true });
				}  else if (i.customId === 'view') {
					const msgEmbed = new EmbedBuilder()
						.setTitle(`Message sent by ${interaction.user.username} (${interaction.user.id})`)
						.setDescription(`Message: ${message}`)
						.setColor("#2f3136")
						.setTimestamp();

					await i.reply({ embeds: [msgEmbed], components: [], ephemeral: true });
				}
			} catch (error) {
				console.error('An error occurred during the collection:', error);
				await i.reply({ content: 'An error occurred while processing your request. Please try again later.', ephemeral: true });
			}
		});

		collector.on('end', () => {
			const timeEnd = new EmbedBuilder()
				.setDescription(`~~${target.username}, you have received a secret message!~~ \n\n-# **MESSAGE EXPIRED**`)
				.setColor("#2f3136")
				.setTimestamp();
                viewButton.setDisabled(true);

                response.edit({
					embeds: [timeEnd],
					components: [row],
				});

            

			//if (collector.size === 0) {
				//response.edit({
					//embeds: [timeEnd],
					//components: [row],
				//});
			//}
		});
	},
};
