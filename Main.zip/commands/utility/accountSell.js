const { SlashCommandBuilder, ButtonBuilder, ButtonStyle, ActionRowBuilder, EmbedBuilder, ComponentType, PermissionsBitField , PermissionFlagsBits} = require('discord.js');

module.exports = {
	data: new SlashCommandBuilder()
		.setName('sell')
		.setDescription('Add game account in shop')
		.setDefaultMemberPermissions(PermissionFlagsBits.BanMembers)
		.addSubcommand(subcommand =>
			subcommand
				.setName("account")
				.setDescription('Add game account in shop')
				.addAttachmentOption(option => option.setName('image').setDescription("Add Image").setRequired(true))
				.addStringOption(option =>
					option
						.setName('cost')
						.setDescription('What is the cost of this account')
						.setRequired(true))
				.addStringOption(option => option.setName('trophy').setDescription(`What's the total trophy`).setRequired(true))
				.addStringOption(option => option.setName('r35').setDescription('How much Rank 35 the account is having?').setRequired(true))
				.addStringOption(option => option.setName('r30').setDescription(`How much Rank 30 the account is having?`).setRequired(true))
				.addStringOption(option => option.setName('description').setDescription(`Tell us more about the account`).setRequired(false))
		),

	async execute(interaction) {
		const buy = new ButtonBuilder()
			.setCustomId('buy')
			.setLabel('Click here to Buy')
			.setStyle(ButtonStyle.Secondary);

		const sold = new ButtonBuilder()
			.setCustomId('sold')
			.setLabel('Mark it as Sold')
			.setStyle(ButtonStyle.Danger);

		const row = new ActionRowBuilder()
			.addComponents(buy, sold);

		const cost = interaction.options.getString('cost');
		const image = interaction.options.getAttachment('image');
		const trophy = interaction.options.getString('trophy');
		const r35 = interaction.options.getString('r35');
		const r30 = interaction.options.getString('r30');
		const description = interaction.options.getString('description') || 'No Account Description Provided.';

		const mainEmbed = new EmbedBuilder()
			.setTitle('New Account in Stock')
			.setDescription(description)
			.addFields(
				{ name: '<:pricelist:1264486306877276170> Price', value: cost, inline: true },
				{ name: '<:trophies:1264486541372428360> Trophies', value: trophy, inline: true },
				{ name: '<:Rank35:1264486619935936584> Rank 35', value: r35, inline: true },
				{ name: '<:30rank:1264486630408978457> Rank 30', value: r30, inline: true },
			)
			.setImage(image.url)
			.setColor("#2f3136")
			.setTimestamp();
			
		await interaction.reply({ content: `Sent`, ephemeral: true });
		const response = await interaction.channel.send({
			embeds: [mainEmbed],
			components: [row],
		});

		const collector = response.createMessageComponentCollector({ componentType: ComponentType.Button });

		collector.on('collect', async i => {
			try {
				if (i.customId === 'sold') {
					if (interaction.member.permissions.has(PermissionsBitField.Flags.Administrator)) {
						const soldEmbed = new EmbedBuilder()
							.setTitle('SOLD')
							.setDescription(`~~${description}~~`)
							.addFields(
								{ name: '~~<:pricelist:1264486306877276170> Price~~', value: `~~${cost}~~`, inline: true },
								{ name: '~~<:trophies:1264486541372428360> Trophies~~', value: `~~${trophy}~~`, inline: true },
								{ name: '~~<:Rank35:1264486619935936584> Rank 35~~', value: `~~${r35}~~`, inline: true },
								{ name: '~~<:30rank:1264486630408978457> Rank 30~~', value: `~~${r30}~~`, inline: true },
							)
							.setColor("#2f3136")
							.setImage(image.url)
							.setTimestamp();
						const srow = new ActionRowBuilder()
							.addComponents(
								new ButtonBuilder()
									.setCustomId('sold')
									.setLabel('This item has been Sold')
									.setStyle(ButtonStyle.Primary)
									.setDisabled(true)
							);

						await response.edit({ content: 'This item has been marked as sold', embeds: [soldEmbed], components: [srow] });
					} else {
						await i.reply({ content: `${interaction.user.username}, you don't have ADMIN perms to mark this item as sold.`, ephemeral: true });
					}
				} else if (i.customId === 'buy') {
					const categoryId = '1264261418111336458'; // replace with your category ID
					const channelName = `buy-${i.user.username}`;

					const newChannel = await interaction.guild.channels.create({
						name: channelName,
						type: '0',
						parent: categoryId,
						permissionOverwrites: [
							{
								id: interaction.guild.id,
								deny: [PermissionsBitField.Flags.ViewChannel],
							},
							{
								id: interaction.user.id,
								allow: [PermissionsBitField.Flags.ViewChannel, PermissionsBitField.Flags.SendMessages],
							},
							{
								id: interaction.guild.roles.everyone.id, // This is the correct way to reference the @everyone role
								deny: [PermissionsBitField.Flags.ViewChannel],
							},
						],
					});

					const closeButton = new ButtonBuilder()
						.setCustomId('close')
						.setLabel('Close Ticket')
						.setStyle(ButtonStyle.Danger);

					const closeRow = new ActionRowBuilder()
						.addComponents(closeButton);

					const ticketEmbed = new EmbedBuilder()
						.setTitle('Ticket Created')
						.setDescription('This is your ticket. An admin will assist you shortly.')
						.setColor('#2f3136')
                        .setImage(image.url)
						.setTimestamp();
                    await i.reply({content: `${i.user.username}, Your ticket has been made! ${newChannel}`, ephemeral: true})
					const ticketMessage = await newChannel.send({
						content: `Welcome ${i.user.username}`,
						embeds: [ticketEmbed],
						components: [closeRow],
					});

					const ticketCollector = ticketMessage.createMessageComponentCollector({ componentType: ComponentType.Button });

					ticketCollector.on('collect', async buttonInteraction => {
						if (buttonInteraction.customId === 'close') {
							if (buttonInteraction.user.id === interaction.user.id || buttonInteraction.member.permissions.has(PermissionsBitField.Flags.Administrator)) {
								await newChannel.delete();
							} else {
								await buttonInteraction.reply({ content: 'You do not have permission to close this ticket.', ephemeral: true });
							}
						}
					});
				}
			} catch (error) {
				console.error('An error occurred during the collection:', error);
				await i.reply({ content: 'An error occurred while processing your request. Please try again later.', ephemeral: true });
			}
		});
	},
};
