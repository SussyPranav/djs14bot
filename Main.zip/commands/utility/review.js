const { SlashCommandBuilder, ButtonBuilder, ButtonStyle, ActionRowBuilder, EmbedBuilder, ComponentType } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('feedback')
        .setDescription('Send a secret message to someone!')
        .addStringOption(option =>
            option
                .setName('message')
                .setDescription('Your message')
                .setRequired(true))
        .addIntegerOption(option =>
            option
                .setName('ratings')
                .setDescription('Rate us on a scale of 5')
                .setRequired(true)),

    async execute(interaction) {
        const message = interaction.options.getString('message');
        const ratings = interaction.options.getInteger('ratings');
        const stars = '⭐'.repeat(ratings);

        if (ratings > 5) {
            return await interaction.reply({ content: 'Rating should be 5 or below.', ephemeral: true });
        }

        const viewButton = new ButtonBuilder()
            .setCustomId('Approve')
            .setLabel('Approve this Review!')
            .setStyle(ButtonStyle.Secondary);

        const row = new ActionRowBuilder()
            .addComponents(viewButton);

        const viewEmbed = new EmbedBuilder()
            .setDescription(`🔔 New Review Received \nFeedback: ${message}\nRatings: ${stars} \n\n- # Feedback sent by ${interaction.user.username} (${interaction.user.id})`)
            .setColor("#2f3136")
            .setTimestamp();
		
        await interaction.reply({ content: 'Your feedback has been sent for review.', ephemeral: true });

        const channel = interaction.client.channels.cache.get('1263904526721880184');
        const response = await channel.send({
            embeds: [viewEmbed],
            components: [row],
        });

        const collector = response.createMessageComponentCollector({ componentType: ComponentType.Button });

        collector.on('collect', async i => {
            try {
                if (i.customId === 'Approve') {
                    const msgEmbed = new EmbedBuilder()
                        .setTitle(`Feedback submitted by ${interaction.user.username} (${interaction.user.id})`)
                        .setDescription(`- Feedback: ${message}\n- Ratings: ${stars}`)
                        .setColor("#2B2D31")
						
                        .setTimestamp();

                    const channelFs = interaction.client.channels.cache.get('1264239328582828093');
                    await i.reply({ content: 'Approved!', ephemeral: true });
					await channelFs.send({ embeds: [msgEmbed], content: 'This is Test Message.' });
                    await response.edit({ embeds: [viewEmbed], content: `Approved by ${i.user.username} (${i.user.id})` });
                    
                }
            } catch (error) {
                console.error('An error occurred during the collection:', error);
                await i.reply({ content: 'An error occurred while processing your request. Please try again later.', ephemeral: true });
            }
        });

        // Uncomment if you want to handle timeout scenarios
        /*
        collector.on('end', () => {
            const timeEnd = new EmbedBuilder()
                .setDescription(`~~${target.username}, you have received a secret message!~~ \n\n- # **MESSAGE EXPIRED**`)
                .setColor("#2f3136")
                .setTimestamp();
            viewButton.setDisabled(true);

            response.edit({
                embeds: [timeEnd],
                components: [row],
            });
        });
        */
    },
};
